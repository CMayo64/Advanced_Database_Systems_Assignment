# Database Starter Project 
https://radiant-sea-31647.herokuapp.com/ 
## Getting Started

- Clone this repo 
- Install the dependencies -  `npm install`
- Rename .env.example to .env. You won't normally need to change the values in this file.
- If this is your first time getting started then run the seeder - `node seeder`
- Run the project in development mode - `npm run dev`
